import numpy as np


def calculate(list):
    if len(list) != 9:
        print('List must contain nine numbers.')
    else:
        arr = np.array(list).reshape(3, 3)
        mean_rows = arr.mean(axis=0).tolist()
        mean_columns = arr.mean(axis=1).tolist()
        mean_elements = arr.mean().tolist()
        var_rows = arr.var(axis=0).tolist()
        var_columns = arr.var(axis=1).tolist()
        var_elements = arr.var().tolist()
        std_rows = arr.std(axis=0).tolist()
        std_columns = arr.std(axis=1).tolist()
        std_elements = arr.std().tolist()
        max_rows = arr.max(axis=0).tolist()
        max_columns = arr.max(axis=1).tolist()
        max_elements = arr.max().tolist()
        min_rows = arr.min(axis=0).tolist()
        min_columns = arr.min(axis=1).tolist()
        min_elements = arr.min().tolist()
        sum_rows = arr.sum(axis=0).tolist()
        sum_columns = arr.sum(axis=1).tolist()
        sum_elements = arr.sum().tolist()

        calculations = {
            'mean': [mean_rows, mean_columns, mean_elements],
            'variance': [var_rows, var_columns, var_elements],
            'standard deviation': [std_rows, std_columns, std_elements],
            'max': [max_rows, max_columns, max_elements],
            'min': [min_rows, min_columns, min_elements],
            'sum': [sum_rows, sum_columns, sum_elements]
        }

        return calculations
